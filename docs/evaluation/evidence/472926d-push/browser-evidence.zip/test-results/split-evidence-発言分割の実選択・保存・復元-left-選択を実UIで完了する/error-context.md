# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: split-evidence.spec.ts >> 発言分割の実選択・保存・復元 >> left 選択を実UIで完了する
- Location: e2e/split-evidence.spec.ts:68:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.recent-open').filter({ hasText: 'e2e-split-evidence' }).first()
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('.recent-open').filter({ hasText: 'e2e-split-evidence' }).first() with timeout 5000ms
  - waiting for locator('.recent-open').filter({ hasText: 'e2e-split-evidence' }).first()

```

```yaml
- banner:
  - button "論点整理."
  - text: 会話本文を外部送信しません
  - button "使い方"
- main:
  - text: LOCAL-FIRST CONVERSATION MAP
  - heading "会話の流れを、 見えるかたちに。" [level=1]
  - paragraph: 何が問われ、どこへ広がり、何が残ったのか。 議題をたどって、根拠の原文へ。 「論破」ではなく、理解のための論点整理。
  - button "新しく始める"
  - button "サンプルを見てみる"
  - text: アカウント不要 · 会話本文は端末内で処理 設計検証版 手動整理・操作検証のための実装です。AIの日本語品質と対応端末は評価中です。
  - region "議題の流れのイメージ":
    - text: 議題01 — 在宅勤務の試行 未決 会話の始まり 発言順 → U01 · 起点
    - strong: 試してみたい
    - text: 本筋 U07 · 条件の検討
    - strong: 新人対応は？
    - text: 本筋 U10 · 復帰
    - strong: 条件付きで検討
    - text: 本筋 ↳ 派生
    - strong: 効果をどう測る？
    - text: 応答速度・満足度 ↳ ずれ候補
    - strong: 採用全般の話へ
    - text: ↗ 後の発言で本筋へ復帰 原文に戻り、確かめて、直せる。 架空の会話を使った、議題ブロックの例
  - article:
    - text: "01"
    - heading "議題をひとまとまりに" [level=3]
    - paragraph: 本筋も派生もずれも、議題が変わるまでは同じ枠に。
  - article:
    - text: "02"
    - heading "いつでも原文へ戻れる" [level=3]
    - paragraph: 推定と記録を分けて、読み違いを履歴付きで訂正。
  - article:
    - text: "03"
    - heading "残った問いを、次の一手に" [level=3]
    - paragraph: 回答・合意・決定・外部確認を、一つにまとめない。
  - heading "最近の作業" [level=2]
  - button "JSONから復元"
  - paragraph: 保存した作業がここに表示されます。ブラウザ保存は消去されることがあるため、JSONの控えも保管してください。
  - text: 論点整理 · ローカルファーストの設計検証版
  - button "処理・保存・分析の制約について"
```

# Test source

```ts
  41  |   project = linkResponse(project, {
  42  |     questionVersionId,
  43  |     utteranceIds: [target.id],
  44  |     kind: "answer",
  45  |     fulfillment: "fulfilled",
  46  |     actor: "manual",
  47  |     time,
  48  |     counterargumentToClaimIds: [],
  49  |     evidenceIds: [evidenceId],
  50  |   });
  51  |   return {
  52  |     project,
  53  |     target,
  54  |     evidenceId,
  55  |     questionVersionId,
  56  |     responseId: project.reasoning!.responses[0].id,
  57  |   };
  58  | }
  59  | 
  60  | test.describe("発言分割の実選択・保存・復元", () => {
  61  |   test.describe.configure({ mode: "serial" });
  62  |   for (const destination of [
  63  |     "left",
  64  |     "right",
  65  |     "both",
  66  |     "unresolved",
  67  |   ] as Destination[])
  68  |     test(`${destination} 選択を実UIで完了する`, async ({ page }) => {
  69  |       const { project, target, evidenceId, questionVersionId, responseId } =
  70  |         await makeFixture();
  71  |       const originalUtteranceIds = project.utterances.map((u) => u.id);
  72  |       const originalOtherUtterances = project.utterances.filter(
  73  |         (u) => u.id !== target.id,
  74  |       );
  75  |       const originalEvidence = project.reasoning!.evidence.find(
  76  |         (e) => e.id === evidenceId,
  77  |       )!;
  78  |       const originalQuestionVersion = project.reasoning!.questionVersions.find(
  79  |         (q) => q.id === questionVersionId,
  80  |       )!;
  81  |       const originalResponse = project.reasoning!.responses.find(
  82  |         (r) => r.id === responseId,
  83  |       )!;
  84  |       const json = exportProject(project, "json");
  85  |       await page.goto("/");
  86  |       await page.getByLabel("JSONから復元").setInputFiles({
  87  |         name: "fixture.rontenseiri.json",
  88  |         mimeType: "application/json",
  89  |         buffer: Buffer.from(json),
  90  |       });
  91  |       await expect(
  92  |         page
  93  |           .getByRole("banner")
  94  |           .getByText("e2e-split-evidence", { exact: true }),
  95  |       ).toBeVisible();
  96  | 
  97  |       await page
  98  |         .getByRole("button", { name: "発言と原文", exact: true })
  99  |         .click();
  100 |       const targetRow = page
  101 |         .getByRole("button")
  102 |         .filter({ hasText: "left right" })
  103 |         .first();
  104 |       await expect(targetRow).toBeVisible();
  105 |       await targetRow.click();
  106 |       const detail = page.getByRole("complementary", {
  107 |         name: "選択した発言の詳細",
  108 |       });
  109 |       await expect(detail).toBeVisible();
  110 |       await expect(detail).toContainText(target.id);
  111 |       await detail.getByText("発言本文の区切りを編集", { exact: true }).click();
  112 |       await expect(
  113 |         detail.getByText("分割後の解釈参照先", { exact: true }),
  114 |       ).toBeVisible();
  115 |       const selects = detail.locator('select[aria-label$="の分割先"]');
  116 |       await expect(selects).toHaveCount(3);
  117 |       for (const id of [evidenceId, responseId, questionVersionId]) {
  118 |         const select = detail.locator(`select[aria-label="${id} の分割先"]`);
  119 |         await expect(select).toBeVisible();
  120 |         await select.selectOption(destination);
  121 |       }
  122 |       await detail
  123 |         .getByLabel("区切り・関係の変更理由")
  124 |         .fill(`E2E ${destination} 選択`);
  125 |       await detail.getByLabel("先頭から何文字で分けるか").fill("4");
  126 |       await detail
  127 |         .getByRole("button", { name: "この発言を2つに分ける", exact: true })
  128 |         .click();
  129 |       await expect(detail).toContainText("A: l");
  130 |       await page
  131 |         .getByRole("button", { name: "この端末に保存", exact: true })
  132 |         .click();
  133 |       await expect(page.getByRole("status")).toContainText("保存");
  134 | 
  135 |       await page.reload();
  136 |       await expect(page.getByText("最近の作業", { exact: true })).toBeVisible();
  137 |       const recent = page
  138 |         .locator(".recent-open")
  139 |         .filter({ hasText: "e2e-split-evidence" })
  140 |         .first();
> 141 |       await expect(recent).toBeVisible();
      |                            ^ Error: expect(locator).toBeVisible() failed
  142 |       await recent.click();
  143 |       await expect(
  144 |         page
  145 |           .getByRole("banner")
  146 |           .getByText("e2e-split-evidence", { exact: true }),
  147 |       ).toBeVisible();
  148 | 
  149 |       await page.getByRole("button", { name: "出力", exact: true }).click();
  150 |       await expect(
  151 |         page.getByRole("dialog", { name: "資料を出力する" }),
  152 |       ).toBeVisible();
  153 |       const dialog = page.getByRole("dialog", { name: "資料を出力する" });
  154 |       await dialog
  155 |         .getByRole("button", { name: "出力内容をプレビュー", exact: true })
  156 |         .click();
  157 |       const preview = dialog.locator("pre.export-preview");
  158 |       const parsedEnvelope = JSON.parse((await preview.textContent()) ?? "");
  159 |       const parsed = parsedEnvelope.project;
  160 |       const record = [...(parsed.lineage?.records ?? [])]
  161 |         .reverse()
  162 |         .find(
  163 |           (candidate: { operation?: string; oldIds?: string[] }) =>
  164 |             candidate.operation === "split" &&
  165 |             candidate.oldIds?.includes(target.id),
  166 |         );
  167 |       expect(record).toBeDefined();
  168 |       const newIds = record.newIds as [string, string];
  169 |       const expectedReferenceIds = {
  170 |         evidence: newIds,
  171 |         response: newIds,
  172 |         questionVersion: newIds,
  173 |       };
  174 |       const expectedIds =
  175 |         destination === "left"
  176 |           ? [newIds[0]]
  177 |           : destination === "right"
  178 |             ? [newIds[1]]
  179 |             : newIds;
  180 |       const expectedUnresolved = destination === "unresolved";
  181 |       const expectedReasoningIds = expectedUnresolved ? newIds : expectedIds;
  182 |       const responseUtteranceIds = (parsed.reasoning.responses.find(
  183 |         (r: { id: string }) => r.id === responseId,
  184 |       ) as { utteranceIds?: string[]; sourceUtteranceIds?: string[] })!;
  185 |       expect(
  186 |         new Set(parsed.utterances.map((u: { id: string }) => u.id)),
  187 |       ).toEqual(
  188 |         new Set([
  189 |           ...originalUtteranceIds.filter((id) => id !== target.id),
  190 |           ...newIds,
  191 |         ]),
  192 |       );
  193 |       for (const original of originalOtherUtterances) {
  194 |         const expected = {
  195 |           ...JSON.parse(JSON.stringify(original)),
  196 |           order:
  197 |             original.order > target.order ? original.order + 1 : original.order,
  198 |         };
  199 |         expect(
  200 |           parsed.utterances.find((u: { id: string }) => u.id === original.id),
  201 |         ).toEqual(expected);
  202 |       }
  203 |       expect(
  204 |         parsed.reasoning.evidence.find(
  205 |           (e: { id: string }) => e.id === evidenceId,
  206 |         ).utteranceIds,
  207 |       ).toEqual(expectedReasoningIds);
  208 |       expect(
  209 |         parsed.reasoning.questionVersions.find(
  210 |           (q: { id: string }) => q.id === questionVersionId,
  211 |         ).sourceUtteranceIds,
  212 |       ).toEqual(expectedReasoningIds);
  213 |       expect(
  214 |         responseUtteranceIds.sourceUtteranceIds ??
  215 |           responseUtteranceIds.utteranceIds,
  216 |       ).toEqual(expectedReasoningIds);
  217 |       expect(
  218 |         parsed.reasoning.responses.find(
  219 |           (r: { id: string }) => r.id === responseId,
  220 |         ).fulfillment,
  221 |       ).toBe("unassessed");
  222 |       expect(record.status).toBe("pending");
  223 |       for (const [referenceId, referenceIds] of Object.entries(
  224 |         expectedReferenceIds,
  225 |       )) {
  226 |         const reasoningId =
  227 |           referenceId === "evidence"
  228 |             ? evidenceId
  229 |             : referenceId === "response"
  230 |               ? responseId
  231 |               : questionVersionId;
  232 |         const ref = record.references.find(
  233 |           (candidate: { referenceId: string }) =>
  234 |             candidate.referenceId === reasoningId,
  235 |         );
  236 |         expect(ref).toBeDefined();
  237 |         expect(ref.targetIds).toEqual(
  238 |           expectedUnresolved ? referenceIds : expectedIds,
  239 |         );
  240 |         expect(ref.status).toBe(expectedUnresolved ? "unresolved" : "applied");
  241 |       }
```